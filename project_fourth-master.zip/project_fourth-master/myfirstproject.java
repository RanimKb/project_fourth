public class myproject{
 String p="my first project";
	public myproject (){
		super();
		x="we will modify the project here ";
	}
	public void printme (){
		System.out.print("welcom !!!!!");
	}
	
   public void print_numbers()
   {
	   for(int i=1;i<=10;i++)
		   System.out.println(i);
	   
   }
	
	
}
