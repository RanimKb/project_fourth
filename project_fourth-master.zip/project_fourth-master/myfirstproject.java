public class myproject{
 String p="my first project";
	public myproject (){
		super();
		x="we are three cute girl ";
	}
	public void printme (){
		System.out.print("welcom !!!!!");
	}
}
